var queue; // LoadQueue
var stage; // Stage
var blocks; // Our landscape in a 2D array
var dirt;

// Landscape Generation Vars
var stageXdimens;
var stageYdimens;
var stageXblocks;
var stageYblocks;
var landMin;
var landMax;
var landBlockSize;
var maxLandDev;

// Player Tank Vars
var p1Tank;
var p1TankBitmap;
var p1TankBarrel;
var p2Tank;
var p2TankBitmap;
var p2TankBarrel;

//Player Control Vars
var p1Rright;
var p1Rleft;
var p2Rleft;
var p2Rright;
var p1RrightPressed;
var p1RleftPressed;
var p2RleftPressed;
var p2RrightPressed;

var g;


//Data displays
var p1elev;
var p2elev;

function load() {
    queue = new createjs.LoadQueue(false);
    queue.on("complete", init, this);
    queue.loadManifest([
        { id: "p1TankPNG", src: "red_tank.png" },
        { id: "p1TankBarrel", src: "red_tank_barrel.png" },
        { id: "p2TankPNG", src: "green_tank.png" },
        { id: "p2TankBarrel", src: "green_tank_barrel.png" },
    ]);
}

function init() {
    stage = new createjs.Stage("canvas");
    g = new createjs.Graphics();

    initButtons();
    landGeneration();
    addTanks();

    p1elev = new createjs.Text(p1TankBarrel.rotation, "20px Arial", "#000000");
    p1elev.x = 100;
    p1elev.y = 30;
    stage.addChild(p1elev);

    p2elev = new createjs.Text(p2TankBarrel.rotation, "20px Arial", "#000000");
    p2elev.x = 500;
    p2elev.y = 30;
    stage.addChild(p2elev);

    stage.update();
    createjs.Ticker.setFPS(60);
    createjs.Ticker.addEventListener("tick", tick);
}

function p1rotateRight() {
    p1TankBarrel.rotation = p1TankBarrel.rotation + 1;

}


function tick(event) {
    if (p1RleftPressed && (p1TankBarrel.rotation > -180)) {
        p1TankBarrel.rotation = p1TankBarrel.rotation - 1;
        p1elev.text = -(p1TankBarrel.rotation);
    }
    if (p1RrightPressed && (p1TankBarrel.rotation < 0)) {
        p1TankBarrel.rotation = p1TankBarrel.rotation + 1;
        p1elev.text = -(p1TankBarrel.rotation);
    }


    if (p2RleftPressed && (p2TankBarrel.rotation > -180)) {
        p2TankBarrel.rotation = p2TankBarrel.rotation - 1;
        p2elev.text = -(p2TankBarrel.rotation);
    }
    if (p2RrightPressed && (p2TankBarrel.rotation < 0)) {
        p2TankBarrel.rotation = p2TankBarrel.rotation + 1;
        p2elev.text = -(p2TankBarrel.rotation);
    }

    if (!event.paused) {
        stage.update();
    }

}

function addTanks() {
    // Get our images
    p1TankPNG = new createjs.Bitmap(queue.getResult("p1TankPNG"));
    p1TankBarrel = new createjs.Bitmap(queue.getResult("p1TankBarrel"));
    p2TankPNG = new createjs.Bitmap(queue.getResult("p2TankPNG"));
    p2TankBarrel = new createjs.Bitmap(queue.getResult("p2TankBarrel"));

    p1TankBarrel.regX = 0;
    p1TankBarrel.regY = 2.5;

    p2TankBarrel.regX = 0;
    p2TankBarrel.regY = 2.5;

    p1TankBarrel.x = 10;
    p1TankBarrel.y = 10;

    p2TankBarrel.y = 10;
    p2TankBarrel.x = 10;



    p1Tank = new createjs.Container();
    p1Tank.addChild(p1TankBarrel);

    p1Tank.addChild(p1TankPNG);

    p2Tank = new createjs.Container();
    p2Tank.addChild(p2TankBarrel);

    p2Tank.addChild(p2TankPNG);

    // Find the starting positions for the tanks
    var p1pos = (blocks[5].length); // 0;
    // alert("Hello!");
    // for (var y = 0; y < stageYblocks; y++)
    // {
    //     alert("Hi!");
    //     alert(blocks[4][y]);
    //     // console.log(blocks[4][y]);
    //     if (blocks[4][y] == null) {
    //         p1pos = y;
    //     }
    //     else {
    //         break;
    //     }
    // }
    var p2pos = (blocks[30].length); // 0;
    // for (var y = 0; y < stageYblocks; y++)
    // {
    //     if (blocks[stageXblocks - 5][y] == null) {
    //         p2pos = y;
    //     }
    //     else {
    //         break;
    //     }
    // }

    p1Tank.x = landBlockSize * 5
    p1Tank.y = stageYdimens - (landBlockSize * p1pos);



    p2Tank.x = (30) * landBlockSize;
    p2Tank.y = stageYdimens - (landBlockSize * p2pos);

    stage.addChild(p1Tank);
    stage.addChild(p2Tank);
    //alert("Hi!");
}
//initializes the buttons for controlling the tanks
function initButtons() {

    //Player 1 Button Initialization
    p1Rright = new createjs.Shape();
    p1Rright.graphics.beginStroke("#000000").beginFill("#e0370d").drawPolyStar(15, 15, 15, 3, .5, 0);

    p1Rleft = new createjs.Shape();
    p1Rleft.graphics.beginStroke("#000000").beginFill("#e0370d").drawPolyStar(15, 15, 15, 3, .5, 180);


    p1Rleft.on("mousedown", function() {
        p1RleftPressed = true;
    });
    p1Rleft.on("pressup", function() {
        p1RleftPressed = false;
    });

    p1Rright.on("mousedown", function() {
        p1RrightPressed = true;
    })

    p1Rright.on("pressup", function() {
        p1RrightPressed = false;
    });

    p1Rright.x = 60;
    p1Rright.y = p1Rleft.y = 25;
    p1Rleft.x = 40;



    stage.addChild(p1Rright, p1Rleft, p1elev);

    //Player 2 Button Initialization
    p2Rright = new createjs.Shape();
    p2Rright.graphics.beginStroke("#000000").beginFill("#0f8e33").drawPolyStar(15, 15, 15, 3, .5, 0);

    p2Rleft = new createjs.Shape();
    p2Rleft.graphics.beginStroke("#000000").beginFill("#0f8e33").drawPolyStar(15, 15, 15, 3, .5, 180);


    p2Rleft.on("mousedown", function() {
        p2RleftPressed = true;
    });
    p2Rleft.on("pressup", function() {
        p2RleftPressed = false;
    });

    p2Rright.on("mousedown", function() {
        p2RrightPressed = true;
    })

    p2Rright.on("pressup", function() {
        p2RrightPressed = false;
    });

    p2Rright.x = 460;
    p2Rright.y = p2Rleft.y = 25;
    p2Rleft.x = 440;



    stage.addChild(p2Rright, p2Rleft, p2elev);

}

function landGeneration() {
    stageXdimens = stage.canvas.width;
    stageYdimens = stage.canvas.height;
    landBlockSize = 20;
    maxLandDev = 1; // The max amount the land can deviate per step either way when generating
    landMin = (stageYdimens / landBlockSize) * 0.20; // Land must be at least 20% above bottom
    landMax = (stageYdimens / landBlockSize) * 0.60; // Land must not exceed 60% above bottom
    stage.update(); // why is this here?

    // Create the graphics block used to make landscape blocks
    g.beginStroke("#8B4513").beginFill("#D2691E");
    g.drawRect(0, 0, landBlockSize, landBlockSize);

    // Get the starting position for the landscape
    var m = getRandomInt(landMin, landMax);

    blocks = get2DArray(stageXdimens / landBlockSize);

    // Add random blocks as terrain
    for (i = 0; i < stageXdimens / landBlockSize; i++) {
        m = getRandomInt(m - maxLandDev, m + maxLandDev + 1);
        if (m < landMin) {
            m = landMin;
        }
        if (m > landMax) {
            m = landMax;
        }
        for (j = 0; j < m; j++) {
            blocks[i][j] = new createjs.Shape(g);
        }
    }

    // Place blocks on the correct screen positions
    for (i = 0; i < blocks.length; i++) {
        for (j = 0; j < blocks[i].length; j++) {
            blocks[i][j].x = landBlockSize * i;
            blocks[i][j].y = y_bot(landBlockSize * j);
            stage.addChild(blocks[i][j]);
        }
    }

    stageXblocks = blocks.length;
    stageYblocks = blocks[0].length;
}

function y_bot(y) {
    return (stageYdimens - y);
}

function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
}

function get2DArray(size) {
    size = size > 0 ? size : 0;
    var arr = [];

    while (size--) {
        arr.push([]);
    }

    return arr;
}

/*function drawGround(graphics) {
    var g = graphics;
    for (i = 0; i < (stageXdimens / 20); i++) {
        for (j = 0; j < (stageYdimens / 20) - 200; j++) {
            blocks
        }
    }
}*/

/*function buildGround(graphics) {
    var g = graphics;
    var arr = get2DArray(stageXdimens / 20);
    for (i = 0; i < (stageXdimens / 20); i++) {
        for (j = 0; j < (stageYdimens / 20) - 200; j++) {
            arr[i][j] = new createjs.Shape(g);
        }
    }

    return arr;
}*/